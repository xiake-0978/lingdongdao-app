package com.lingdongdao

import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class ThemeActivity : AppCompatActivity() {
    private lateinit var sp: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_theme)
        sp = getSharedPreferences("island_setting", MODE_PRIVATE)

        findViewById<MaterialButton>(R.id.themeBlack).setOnClickListener {
            sp.edit().putString("theme","black").apply()
        }
        findViewById<MaterialButton>(R.id.themePurple).setOnClickListener {
            sp.edit().putString("theme","purple").apply()
        }
        findViewById<MaterialButton>(R.id.themePink).setOnClickListener {
            sp.edit().putString("theme","pink").apply()
        }
        findViewById<MaterialButton>(R.id.themeGlass).setOnClickListener {
            sp.edit().putString("theme","glass").apply()
        }
    }
}
