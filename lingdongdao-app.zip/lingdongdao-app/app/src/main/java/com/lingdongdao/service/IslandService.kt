package com.lingdongdao.service

import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.lingdongdao.R

class IslandService : Service(){
    private lateinit var windowManager: WindowManager
    private lateinit var islandView: View
    private val handler = Handler(Looper.getMainLooper())
    private var islandExpanded = false
    private lateinit var sp: SharedPreferences
    private var countDownTimer: CountDownTimer? = null
    private var musicPlaying = false

    override fun onCreate() {
        super.onCreate()
        sp = getSharedPreferences("island_setting", MODE_PRIVATE)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createIslandView()
        applyTheme()
    }

    private fun createIslandView(){
        islandView = LayoutInflater.from(this).inflate(R.layout.island_capsule,null)
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = 35

        islandView.setOnClickListener {
            toggleExpand()
        }
        windowManager.addView(islandView,params)
    }

    //读取主题
    private fun applyTheme(){
        val selectedTheme = sp.getString("theme","black")
        when(selectedTheme){
            "black"->{
                islandView.background = resources.getDrawable(R.drawable.bg_island_capsule)
            }
            "purple"->{
                islandView.setBackgroundColor(0xCC6A0DAD)
            }
            "pink"->{
                islandView.setBackgroundColor(0xCCFFB6C1)
            }
            "glass"->{
                islandView.background = resources.getDrawable(R.drawable.bg_glass)
            }
        }
    }

    //胶囊展开/收起
    private fun toggleExpand(){
        islandExpanded = !islandExpanded
        val tv = islandView.findViewById<TextView>(R.id.tvIslandText)
        if(islandExpanded){
            tv.text = "⏱计时器｜🎵音乐"
            startRealTimer()
            startMusicSimulate()
        }else{
            tv.text = "灵动岛"
            countDownTimer?.cancel()
        }
    }

    //倒计时计时器
    private fun startRealTimer(){
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(3*60*1000,1000){
            override fun onTick(millisUntilFinished: Long) {
                val min = millisUntilFinished / 60000
                val sec = (millisUntilFinished % 60000)/1000
                islandView.findViewById<TextView>(R.id.tvIslandText).text = "⏰剩余：${min}分${sec}秒"
            }
            override fun onFinish() {
                islandView.findViewById<TextView>(R.id.tvIslandText).text = "✅计时结束！"
            }
        }.start()
    }

    //音乐播放模拟
    private fun startMusicSimulate(){
        musicPlaying = true
        handler.postDelayed(object:Runnable{
            override fun run() {
                if(musicPlaying){
                    islandView.findViewById<TextView>(R.id.tvIslandText).text = "🎵正在播放歌曲"
                    handler.postDelayed(this,5000)
                }
            }
        },2000)
    }

    private fun removeView(){
        if(::islandView.isInitialized){
            windowManager.removeView(islandView)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        removeView()
        handler.removeCallbacksAndMessages(null)
        countDownTimer?.cancel()
        musicPlaying = false
    }
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
