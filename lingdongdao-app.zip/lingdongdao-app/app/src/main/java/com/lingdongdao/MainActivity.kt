package com.lingdongdao

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private val OVERLAY_PERMISSION_CODE = 1001
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<MaterialButton>(R.id.btnStartIsland)
        val btnTheme = findViewById<MaterialButton>(R.id.btnGoTheme)

        btnStart.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, com.lingdongdao.service.IslandService::class.java))
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivityForResult(intent, OVERLAY_PERMISSION_CODE)
            }
        }
        btnTheme.setOnClickListener {
            startActivity(Intent(this, ThemeActivity::class.java))
        }
    }
}
